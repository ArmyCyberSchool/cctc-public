#/bin/bash

file1="flag.txt"
for i in {1..1337}; do
    num=$(($RANDOM%3))
    file2=$(head -c 1024 /dev/urandom | md5sum | cut -c1-32)
    if [ "$num" -eq 0 ]; then
        tar -cf "$file2" "$file1"
        rm "$file1"
        file1="$file2"
        echo "tar'd"
    elif [ "$num" -eq 1 ]; then
        gzip "$file1"
        file1=$(file $(ls) | grep .gz | cut -d ':' -f 1)
        mv "$file1" "$file2"
        file1="$file2"
        echo "gzip'd"
    elif [ "$num" -eq 2 ]; then
        bzip2 "$file1"
        file1=$(file $(ls) | grep .bz2 | cut -d ':' -f 1)
        mv "$file1" "$file2"
        file1="$file2"
        echo "bzip2'd"
    fi
done
