#!/bin/bash

exit="false"
filein=$1
echo "$filein"

while [ "$exit" = "false" ]; do
    if [ "$(file $filein | grep tar)" != "" ]; then
        tar -xf "$filein"
        rm "$filein"
        echo "un-tar'd"
    elif [ "$(file $filein | grep bzip)" != "" ]; then
        mv "$filein" "$filein.bz2"
        bzip2 -d "$filein.bz2"
        echo "un-bzip2'd"
    elif [ "$(file $filein | grep gzip)" != "" ]; then
        mv "$filein" "$filein.gz"
        gzip -d "$filein.gz"
        echo "un-gzip'd"
    fi
    filein=""
    for line in $(ls); do
        if [ "$(file $line | grep -e tar -e bzip -e gzip | cut -d ':' -f1)" != "" ]; then
            filein=$line
        fi
    done
    if [ "$filein" = "" ]; then
        exit="true"
    fi
done
